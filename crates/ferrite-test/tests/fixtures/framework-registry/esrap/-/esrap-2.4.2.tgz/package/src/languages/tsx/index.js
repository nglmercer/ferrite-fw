/** @import { TSESTree } from '@typescript-eslint/types' */
/** @import { BaseNode, Visitors } from '../../types.js' */
/** @import { TSOptions } from '../types.js' */
import ts from '../ts/index.js';

/**
 * @param {TSOptions} [options]
 * @returns {Visitors<BaseNode>}
 */
export default (options) => {
	/** @type {Visitors<TSESTree.Node>} */
	const visitors = {
		.../** @type {Visitors<TSESTree.Node>} */ (ts(options)),

		TSTypeParameterDeclaration(node, context) {
			context.write('<');

			for (let i = 0; i < node.params.length; i++) {
				if (i > 0) context.write(', ');
				context.visit(node.params[i]);
			}

			// Keep single-parameter declarations unambiguous with JSX.
			if (node.params.length === 1) context.write(',');
			context.write('>');
		},

		JSXElement(node, context) {
			context.visit(node.openingElement);

			if (node.children.length > 0) {
				context.indent();
			}

			for (const child of node.children) {
				context.visit(child);
			}

			if (node.children.length > 0) {
				context.dedent();
			}

			if (node.closingElement) {
				context.visit(node.closingElement);
			}
		},

		JSXOpeningElement(node, context) {
			context.write('<');

			context.visit(node.name);

			// explicit type arguments (`<Comp<string> ... />`)
			if (node.typeArguments) {
				context.visit(node.typeArguments);
			}

			for (const attribute of node.attributes) {
				context.write(' ');
				context.visit(attribute);
			}

			if (node.selfClosing) {
				context.write(' /');
			}

			context.write('>');
		},

		JSXClosingElement(node, context) {
			context.write('</');

			context.visit(node.name);

			context.write('>');
		},

		JSXNamespacedName(node, context) {
			context.visit(node.namespace);
			context.write(':');
			context.visit(node.name);
		},

		JSXIdentifier(node, context) {
			context.write(node.name, node);
		},

		JSXMemberExpression(node, context) {
			context.visit(node.object);
			context.write('.');
			context.visit(node.property);
		},

		JSXText(node, context) {
			// `value` is decoded — re-emitting it would turn `&lt;`, `&gt;`, `&#123;`
			// and `&#125;` back into characters that can't appear in JSX text
			context.write(node.raw ?? node.value, node);
		},

		JSXAttribute(node, context) {
			context.visit(node.name);
			if (node.value) {
				context.write('=');
				context.visit(node.value);
			}
		},

		JSXEmptyExpression(node, context) {},

		JSXFragment(node, context) {
			context.visit(node.openingFragment);

			if (node.children.length > 0) {
				context.indent();
			}

			for (const child of node.children) {
				context.visit(child);
			}

			if (node.children.length > 0) {
				context.dedent();
			}

			context.visit(node.closingFragment);
		},

		JSXOpeningFragment(node, context) {
			context.write('<>');
		},

		JSXClosingFragment(node, context) {
			context.write('</>');
		},

		JSXExpressionContainer(node, context) {
			context.write('{');

			context.visit(node.expression);

			context.write('}');
		},

		JSXSpreadChild(node, context) {
			context.write('{...');

			context.visit(node.expression);

			context.write('}');
		},

		JSXSpreadAttribute(node, context) {
			context.write('{...');

			context.visit(node.argument);

			context.write('}');
		}
	};

	// Accept compatible ASTs from other parsers at the public boundary.
	return /** @type {Visitors<BaseNode>} */ (visitors);
};
